/*
 * File:	scu_solaris.c
 * Author:      Robin T. Miller
 * Date:        February 15th, 2002
 *
 * Description:
 *      This file contains functions specific for the Solaris SCSI
 * pass-through API.
 *
 * Modification History:
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <dirent.h>
#include <limits.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/scsi/impl/uscsi.h>

#include <io/common/iotypes.h>
#include <io/cam/cam.h>
#include <io/cam/dec_cam.h>
#include <io/cam/scsi_special.h>
#include <io/cam/uagt.h>

#include <io/cam/scsi_cdbs.h>
#include <io/cam/scsi_opcodes.h>
#include <io/cam/scsi_status.h>

#include "scu.h"
#include "scu_device.h"
#include "scu_debug.h"
#include "scu_global.h"
#include "scu_protos.h"
#include "inquiry.h"

/*
 * For reference, definitions used by DEC CAM for timeouts are:
 *
 *    CAM_TIME_DEFAULT		0x00000000	Use SIM default value.
 *    CAM_TIME_INFINITY		0xFFFFFFFF	Infinite timeout for I/O.
 *    SIM_DEFAULT_TIMEOUT	30		Default is thirty seconds.
 */
#define SOLARIS_TIME_INFINITY	0xFFFF		/* Max 16-bit timeout. */

/*
 * Default flags for SCSI Pass-through cmds:
 *
 * USCSI_DIAGNOSE = Do not attempt any retries or other error recovery.
 * USCSI_SILENT = Do not print any console error messages or warnings.
 */
#define USCSI_DEFAULT_FLAGS	(USCSI_DIAGNOSE | USCSI_SILENT)

/*
 * Don't use define's from dec_cam.h:
 */
#undef MAX_TARGETS
#undef MAX_LUNS
/*
 * The max bus, target, and lun are defined in scu.h:
 */
#define MAX_TARGETS             (MAX_SCSI_TARGET + 1)
#define MAX_LUNS                (MAX_SCSI_LUN + 1)
#define SCSI_BUSES              (MAX_SCSI_BUS + 1)

#define DEV_DIR_PREFIX		"/dev/"
#define DEV_DIR_LEN		(sizeof(DEV_DIR_PREFIX) - 1)
#define DEV_LIST_LEN		80

/*
 * Local Storage:
 */
static boolean_t devices_scanned = FALSE;
static boolean_t edt_configured = FALSE;
static boolean_t tried_configuring = FALSE;
static int max_bus_seen = -1;

/*
 * EDT structure used keep the device inquiry information.
 *
 * The EDT is a list of SCSI bus pointers.  Each bus entry contains a
 * list of pointers to possible targets, which in turn contains a list
 * pointers for each possible LUN.  If a pointer does not exist, that
 * device does not exist (never seen by scan).  Here's the linkage:
 *
 *       CAM EDT
 * +----------------+     +-------------+     +------------+     +-----------+
 * | scsi bus 0 *** |---->| tgt0 edt ** |---->| lun0 edt * |---->| edt 0/0/0 |
 * +----------------+     +-------------+     +------------+     +-----------+
 * | scsi bus 1 *** |--+  | tgt1 edt ** |--+  | lun1 edt * |--+
 * +----------------+  |  +-------------+  |  +------------+  |  +-----------+
 * |       ...      |  |  |     ...     |  |  |     ...    |  +->| edt 0/0/1 |
 * +----------------+  |  +-------------+  |  +------------+     +-----------+
 *                     |                   |
 *                     |                   |  +------------+     +-----------+
 *                     |                   +->| lun0 edt * |---->| edt 0/1/0 |
 *                     |                      +------------+     +-----------+
 *                     |                      | lun1 edt * |
 *                     |                      +------------|
 *                     |                      |    ...     |
 *                     |                      +------------+
 *                     |
 *                     |  +-------------+     +------------+     +-----------+
 *                     +->| tgt0 edt ** |---->| lun0 edt * |---->| edt 1/0/0 |
 *                        +-------------+     +------------+     +-----------+
 *                        | tgt1 edt ** |--+  | lun1 edt * |--+
 *                        +-------------+  |  +------------+  |  +-----------+
 *                        |     ...     |  |  |    ...     |  +->| edt 1/0/1 |
 *                        +-------------+  |  +------------+     +-----------+
 *                                         |
 *                                         |  +------------+     +-----------+
 *                                         +->| lun ptrs * |---->| edt 1/1/0 |
 *                                            +------------+     +-----------+
 *                                            |    ...     |
 *                                            +------------+
 */

/*
 * Names given to a device:
 */
typedef struct edt_dev_name {
    struct edt_dev_name   *forw;
    struct edt_dev_name   *back;
    struct edt_entry      *edt;
    char                  *name;
} edt_dev_name_t;

/*
 * SCSI Device Information:
 */
typedef struct edt_entry {
    boolean_t	edt_target_lun_found;	/* The target/lun found flag.   */
    edt_dev_name_t *edt_dev_name;	/* Pointer to device name list. */
    boolean_t	edt_did_inquiry;	/* Did Inquiry to device flag.	*/
    inquiry_t	edt_inquiry;		/* The device inquiry data.     */
    u_char	edt_bus;		/* The SCSI bus or adapter.     */
    u_char	edt_controller;
    u_char	edt_target;
    u_char	edt_lun;
    int 	edt_fd;			/* The SDI pass-through fd.	*/
    int		edt_file_flags;
    char	*edt_path;		/* The device path.		*/
} edt_entry_t;

/*
 * SCSI Bus Information:
 */
typedef struct edt {
    u_char	edt_bus_num;
    u_char	edt_max_tid_seen;
    u_char	edt_max_lun_seen;
    u_char	InitiatorBusId;
    char	*AdapterName;
    edt_dev_name_t *edt_dev_name;
    edt_entry_t	***edt;
} edt_t;

#define BUS_TARGET_PTRS (sizeof(edt_entry_t **) * MAX_TARGETS)
#define TARGET_LUN_PTRS (sizeof(edt_entry_t *) * MAX_LUNS)

/*
 * Since we don't have a CAM API to obtain device configuration,
 * we'll setup our own (fake) Equipment Device Table (EDT).
 */
static edt_t *cam_edt[SCSI_BUSES];

static edt_dev_name_t  *edt_dev_names = (edt_dev_name_t *)NULL;

/*
 * External References:
 */
extern int GetDeviceType(struct ccb_getdev      *ccb,
                         struct scsi_inquiry    *inquiry,
                         struct scu_device      *scu );
extern int Fputs(char *str, FILE *stream);
extern void Lputs(char *str);
extern int vSprintf(char *bufptr, const char *msg, va_list ap);

/*
 * Debug Functions:
 */
extern void (*cdbg_printf)(char *fmt, ...);
#define cdp	(*cdbg_printf)

/*
 * Forward References:
 */
int	os_init(void);
int     os_info(CCB_GETDEV *ccb);
int	os_close_device(struct scu_device *scu);
int     os_scan(int full_scan, u_char bus, u_char target, u_char lun);
int     os_switch_nexus(struct scu_device *scu);
int     IssueInquiry (edt_entry_t *edt);
int     IssueRequestSense(edt_entry_t *edt, u_char *sense_buffer,
                                        unsigned sense_length);
int     DoRequestSense (struct scu_device *scu, void *sense_buffer,
                                                int sense_length);
int	SetupEdtEntry(char *path, scu_device_t *scu);
int     GetMaxPaths(void);
static edt_entry_t *FindEdtEntry(u_char pid, u_char tid, u_char lun);
static edt_entry_t *MakeEdtEntry(u_char pid, u_char tid, u_char lun);
static edt_t *MakeAdapterEdtEntry (u_char pid);
#if defined(GetAdapterInformation)
static int GetAdapterName(int fd, edt_entry_t *edt);
#endif /* defined(GetAdapterInformation) */
static int OpenDevice(char *device, int *fdp, boolean_t exclusive);
static edt_entry_t *FindEdtByName(char *device_entry);
static int SetupDevNames(edt_entry_t *edt, char *device_entry);
static void DumpUscsiCmd(int fd, struct uscsi_cmd *scp);
static int DoDeviceScan(void);
static boolean_t isValidDeviceName(char *device_entry);
static int SetupDeviceEntry(char *path, int fd);
static int GetScsiAddress(	char		*path,
				u_char		*bus,
				u_char		*tid,
				u_char		*lun,
				boolean_t	warn_flag);
static int GetTapeAddress(	char		*path,
				u_char		*bus,
				u_char		*tid,
				u_char		*lun,
				boolean_t	warn_flag);

/************************************************************************
 *                                                                      *
 * os_init() - Perform any os-specific Initialization.			*
 *                                                                      *
 * Inputs:	None.							*
 *                                                                      *
 * Return Value:                                                        *
 *		Success/Failure						*
 *                                                                      *
 ************************************************************************/
int
os_init(void)
{
    int error = SUCCESS;

    if (tried_configuring) return (FAILURE);

    /*
     * I haven't found any API's to find adapters and device attached
     * to each adapter (yet), so we'll populate our EDT via scanning
     * the device directories.
     */
    error = DoDeviceScan();

    tried_configuring = TRUE;
    if (max_bus_seen < 0) {
	return (FAILURE);	/* Didn't find any adapters! */
    }
    edt_configured = TRUE;
    return (SUCCESS);
}

int
os_close_device(struct scu_device *scu)
{
    edt_entry_t *edt;
    int error = SUCCESS;

    if (scu->scu_fd != NULL_FD) {
        (void) close (scu->scu_fd);
        scu->scu_fd = NULL_FD;
	if (edt = scu->scu_edt) {
	    edt->edt_fd = NULL_FD;
	}
    }
    return (error);
}

/*
 * This function is called when setting new nexus information via
 * the "sbtl" command, NOT when using the "switch device" command.
 */
int
os_switch_nexus(struct scu_device *scu)
{
    edt_entry_t *edt;
    boolean_t exclusive = FALSE;
    int error;

    error = os_close_device(scu);

    edt = FindEdtEntry (scu->scu_bus, scu->scu_target, scu->scu_lun);
    if (edt == NULL) return (FAILURE);

    scu->scu_edt = edt;
    scu->scu_device_entry = &edt->edt_dev_name->name[DEV_DIR_LEN];
    scu->scu_file_flags = edt->edt_file_flags;

    if ( ExclusiveFlag ) exclusive = TRUE;

    if (edt->edt_fd == NULL_FD) {
	error = OpenDevice(edt->edt_path, &edt->edt_fd, exclusive);
    }
    return (error);
}

/*
 * All SCSI I/O CCB's come into this function.
 */
int
os_ioctl (CCB_SCSIIO *ccb)
{
    struct uscsi_cmd	scsicmd;
    struct uscsi_cmd	*scp = &scsicmd;
    CCB_HEADER		*ccbh = (CCB_HEADER *)ccb;
    edt_entry_t		*edt;
    u_char		*cdbp;
    short		timeout;
    uint_t		transfer_mode = 0;
    boolean_t		tmp_file_open = FALSE;
    int			fd;
    int			error;

    /*
     * Do a temporary switch to another device (if necessary).
     * This will occur for "show edt { serial | status }" cmds.
     */
    edt = FindEdtEntry (ccbh->cam_path_id,
			ccbh->cam_target_id,
			ccbh->cam_target_lun);
    if (!edt) {
	errno = ENXIO;
	ccbh->cam_status = CAM_PATH_INVALID;
	return (FAILURE);
    } else if ( (fd = edt->edt_fd) == NULL_FD) {
        int error = OpenDevice(edt->edt_path, &fd, FALSE);
	if (error) {
	    ccbh->cam_status = CAM_REQ_CMP_ERR;
	    return (error);
	}
	tmp_file_open = TRUE;
    }

    if ( (ccbh->cam_flags & CAM_DIR_NONE) == CAM_DIR_NONE) {
	transfer_mode = 0;
    } else if (ccbh->cam_flags & CAM_DIR_IN) {
	transfer_mode = USCSI_READ;
    } else if (ccbh->cam_flags & CAM_DIR_OUT) {
	transfer_mode = USCSI_WRITE;
    } else {
	Fprintf ("Illegal CAM data direction flags %#x\n",
				ccbh->cam_flags & CAM_DIR_NONE);
	ccbh->cam_status = CAM_REQ_CMP_ERR;
	if (tmp_file_open) {
	    (void)close(fd);
	}
	return (FAILURE);
    }

    /*
     * Setup the Command Descriptor Block (CDB).
     */
    if (ccbh->cam_flags & CAM_CDB_POINTER) {
	cdbp = ccb->cam_cdb_io.cam_cdb_ptr;
    } else {
	cdbp = (u_char *) ccb->cam_cdb_io.cam_cdb_bytes;
    }

    if (ccb->cam_timeout == CAM_TIME_INFINITY) {
	timeout = SOLARIS_TIME_INFINITY;		/* No timeout */
    } else if (ccb->cam_timeout == CAM_TIME_DEFAULT) {
	timeout = SIM_DEFAULT_TIMEOUT;			/* 30 seconds */
    } else {
	timeout = ccb->cam_timeout;			/* seconds -> ms */
    }

    bzero(scp, sizeof(*scp));
    scp->uscsi_cdb = (caddr_t) cdbp;
    scp->uscsi_cdblen = ccb->cam_cdb_len;
    scp->uscsi_bufaddr = (caddr_t) ccb->cam_data_ptr;
    scp->uscsi_buflen = ccb->cam_dxfer_len;
    scp->uscsi_flags = (transfer_mode | USCSI_DEFAULT_FLAGS | USCSI_RQENABLE);
    scp->uscsi_rqlen = ccb->cam_sense_len;
    scp->uscsi_rqbuf = (caddr_t) ccb->cam_sense_ptr;
    scp->uscsi_timeout = timeout;

    /*
     * Finally, execute the SCSI command:
     */
    error = ioctl (fd, USCSICMD, scp);

    if (error) {
	if (PerrorFlag || DebugFlag) {
            Perror ("USCSICMD failed");
	}
	ccbh->cam_status = CAM_REQ_CMP_ERR;
    } else if (scp->uscsi_status != SCSI_STAT_GOOD) {
	ccbh->cam_status = CAM_REQ_CMP_ERR;
    } else {
	ccbh->cam_status = CAM_REQ_CMP;
    }
    if ( (scp->uscsi_status == SCSI_STAT_CHECK_CONDITION) &&
	 (scp->uscsi_rqstatus == SCSI_STAT_GOOD) ) {
	ccbh->cam_status |= CAM_AUTOSNS_VALID;
	ccb->cam_sense_resid = scp->uscsi_rqresid;
    }
    ccb->cam_resid = scp->uscsi_resid;
    ccb->cam_scsi_status = scp->uscsi_status;

    if (DebugFlag) {
	DumpUscsiCmd (fd, scp);
    }

    if (tmp_file_open) {
        (void)close(fd);
    }
    return (SUCCESS);
}

/*
 * Function called for Get Device Type CCB request.
 */
int
os_info (CCB_GETDEV *ccb)
{
    CCB_HEADER		*ccbh = (CCB_HEADER *)ccb;
    edt_entry_t		*edt;
    edt_dev_name_t	*edt_nm;
    static char		device_list[DEV_LIST_LEN];
    int                 status = SUCCESS;

    if (DebugFlag) {
	Printf ("Searching EDT for Bus %u, Target %u, LUN %u...\n",
	ccbh->cam_path_id, ccbh->cam_target_id, ccbh->cam_target_lun);
    }
    bzero (ccb->cam_inq_data, STD_INQ_LEN);
    edt = FindEdtEntry (ccbh->cam_path_id,
			  ccbh->cam_target_id, ccbh->cam_target_lun);

    if (!edt && !edt_configured) {
        if ( (status = os_init()) != SUCCESS) {
	    errno = ENXIO;
	    return (status);
	}
	edt = FindEdtEntry (ccbh->cam_path_id,
			      ccbh->cam_target_id, ccbh->cam_target_lun);
    }
    if (!edt) {
	u_char pid = ccbh->cam_path_id;
	edt_t *e = cam_edt[pid];
	if (e) {
	    ccbh->cam_status = CAM_DEV_NOT_THERE;
	} else {
	    ccbh->cam_status = CAM_PATH_INVALID;
	}
	if ( !e && (ccbh->cam_path_id > max_bus_seen) ) {
	    errno = ENXIO;	/* Let caller know, out of range. */
	} else if ( e &&
		   ((ccbh->cam_path_id > max_bus_seen) ||
		    (ccbh->cam_target_id > e->edt_max_tid_seen) ||
		    (ccbh->cam_target_lun > e->edt_max_lun_seen)) ) {
	    ccbh->cam_status = CAM_DEV_NOT_THERE;
	    errno = EINVAL;	/* Path or target id is invalid. */
	} else {
	    errno = EIO;	/* Non-existant bus and nexus. */
	}
	if (DebugFlag) {
	    Printf("Returning failure with CAM status = 0x%x (%s), errno = %d (%s)\n",
			ccbh->cam_status, cdbg_CamStatus(ccbh->cam_status, CDBG_BRIEF),
			errno, cdbg_SystemStatus(errno));
	}
	return (FAILURE);
    } else {
	ccbh->cam_status = CAM_REQ_CMP;
    }

    if ( !edt->edt_did_inquiry ) {
        int error = IssueInquiry(edt);
	/*
	 * We scan for devices at this point, so we don't do the scan
	 * when a device name is specified on the command line.
	 */
	if (ScanDevicesFlag && !devices_scanned) {
	    (void)DoDeviceScan();	/* Scan for SCSI devices. */
	}
	if (error) {
	    ccbh->cam_status = CAM_REQ_CMP_ERR;
	    bzero(ccb->cam_inq_data, STD_INQ_LEN);
	    return (FAILURE);
	}
    }
    bcopy ((char *)&edt->edt_inquiry, ccb->cam_inq_data, STD_INQ_LEN);
    ccb->cam_pd_type = edt->edt_inquiry.inq_dtype;
    strcpy(device_list, edt->edt_dev_name->name);

    /*
     * Search the global name list:
     */
    for (edt_nm = edt_dev_names; edt_nm; edt_nm = edt_nm->forw) {
	if ((edt_nm->edt == edt) && (edt_nm != edt->edt_dev_name)) {
	    strcat(device_list, " ");
	    strcat(device_list, edt_nm->name);
	}
    }

    ccb->osd_dev_entry = device_list;	/* NOTE: static allocation! */

    return (status);
}

int
os_scan(int full_scan, u_char bus, u_char target, u_char lun)
{
    errno = ENOTSUP;
    return (FAILURE);
}

int
os_path(CCB_PATHINQ *ccb)
{
    edt_t *b = cam_edt[ccb->cam_ch.cam_path_id];

    if (!b && !edt_configured) {
	(void) os_init();
	b = cam_edt[ccb->cam_ch.cam_path_id];
    }
    if (b == NULL) {
	errno = ENXIO;
	return (FAILURE);
    }

    ccb->cam_initiator_id = b->InitiatorBusId;
    ccb->cam_ch.cam_status = CAM_REQ_CMP;
    ccb->cam_osd_usage = b->AdapterName;
    return (SUCCESS);
}

/************************************************************************
 *                                                                      *
 * GetMaxPaths() - Get the Maximum Path ID's supported by the XPT.      *
 *                                                                      *
 * Inputs:      None.                                                   *
 *                                                                      *
 * Return Value:                                                        *
 *              Returns the Maximum XPT Path ID.                        *
 *                                                                      *
 ************************************************************************/
int
GetMaxPaths(void)
{
    return (MAX_SCSI_BUS);
}

/*
 * This function is used when setting up the CAM EDT.
 */
int
IssueInquiry (edt_entry_t *edt)
{
    struct Inquiry_CDB	cdb;
    struct Inquiry_CDB	*cdbp = &cdb;
    struct uscsi_cmd	scsicmd;
    struct uscsi_cmd	*scp = &scsicmd;
    short		timeout = 30;
    inquiry_t		*inq_buffer = &edt->edt_inquiry;
    u_char		inq_length  = sizeof(inquiry_t);
    int			fd;
    boolean_t		temp_file_open = FALSE;
    int			error;

    if ( (fd = edt->edt_fd) == NULL_FD) {
	error = OpenDevice(edt->edt_path, &fd, FALSE);
	if (error) return (error);
	temp_file_open = TRUE;
    }

    if (DebugFlag) {
	Printf("IssueInquiry: Getting Inquiry data for [%u/%u/%u], fd = %d...\n",
				edt->edt_bus, edt->edt_target, edt->edt_lun, fd);
    }

    bzero(cdbp, sizeof(*cdbp));
    cdbp->opcode = SOPC_INQUIRY;
    cdbp->alclen = inq_length;

    bzero(scp, sizeof(*scp));
    scp->uscsi_cdb = (caddr_t) cdbp;
    scp->uscsi_cdblen = sizeof(*cdbp);
    scp->uscsi_bufaddr = (caddr_t) inq_buffer;
    scp->uscsi_buflen = inq_length;
    scp->uscsi_flags = (USCSI_READ | USCSI_DEFAULT_FLAGS);
    scp->uscsi_timeout = timeout;
 
    /*
     * Finally, execute the SCSI command:
     */
    error = ioctl (fd, USCSICMD, scp);

    if (error) {
	if (PerrorFlag || DebugFlag) {
	    Perror ("Inquiry USCSICMD failed");
	}
    } else if (scp->uscsi_status != SCSI_STAT_GOOD) {
	if (PerrorFlag || DebugFlag) {
	    Fprintf ("Inquiry failed, SCSI Status = %#x\n", scp->uscsi_status);
	}
	error = FAILURE;
    } else {
        edt->edt_did_inquiry = TRUE;
        if (DebugFlag) {
            cdbg_DumpInquiryData((ALL_INQ_DATA *)&edt->edt_inquiry);
        }
    }
    if (temp_file_open) {
	(void)close(fd);
    }
    return (error);
}

/*
 * Wrapper that the main 'scu' code calls.
 */
int
DoRequestSense (struct scu_device *scu, void *sense_buffer, int sense_length)
{
    return (IssueRequestSense (scu->scu_edt, (u_char *) sense_buffer,
                                         (unsigned) sense_length));
}

int
IssueRequestSense (edt_entry_t *edt, u_char *sense_buffer, unsigned sense_length)
{
    struct uscsi_cmd	scsicmd;
    struct uscsi_cmd	*scp = &scsicmd;
    int			cdb_length = 6;
    u_char		cdb[6];
    short		timeout = 30;
    int			error;

    if (DebugFlag) {
	Printf("IssueRequestSense: Getting Sense data for [%u/%u/%u]...\n",
				edt->edt_bus, edt->edt_target, edt->edt_lun);
    }

    bzero(cdb, sizeof(cdb));
    cdb[0] = SOPC_REQUEST_SENSE;
    cdb[4] = sense_length;

    bzero(scp, sizeof(*scp));
    scp->uscsi_cdb = (caddr_t) cdb;
    scp->uscsi_cdblen = cdb_length;
    scp->uscsi_bufaddr = (caddr_t) sense_buffer;
    scp->uscsi_buflen = sense_length;
    scp->uscsi_flags = (USCSI_READ | USCSI_DEFAULT_FLAGS);
    scp->uscsi_timeout = timeout;
 
    /*
     * Finally, execute the SCSI command:
     */
    error = ioctl (edt->edt_fd, USCSICMD, scp);

    if (error) {
	if (PerrorFlag || DebugFlag) {
	    Perror ("Request Sense USCSICMD failed");
	}
    } else if (scp->uscsi_status != SCSI_STAT_GOOD) {
	if (PerrorFlag || DebugFlag) {
	    Fprintf ("Request Sense failed, SCSI Status = %#x\n", scp->uscsi_status);
	}
	error = FAILURE;
    } else {
        edt->edt_did_inquiry = TRUE;
        if (DebugFlag) {
            cdbg_DumpSenseData((ALL_REQ_SNS_DATA *)sense_buffer);
        }
    }
    return (error);
}

static edt_entry_t *
FindEdtEntry(u_char pid, u_char tid, u_char lun)
{
	edt_t	*e;

	if ( (pid >= SCSI_BUSES) ||
	     (tid >= MAX_TARGETS) ||
	     (lun >= MAX_LUNS) ) {
	    return (NULL);
	}

	if ((e = cam_edt[pid]) == NULL) {
	    return ((edt_entry_t *) 0);
	}

	if (e->edt[tid] == (edt_entry_t **) 0) {
	    return ((edt_entry_t *) 0);
	}
	return (e->edt[tid][lun]);
}

/*
 * This function is called for the initial "-f device" specified
 * or when a "switch device" command is issued.
 */
int
SetupEdtEntry(char *path, scu_device_t *scu)
{
    u_char	bus, tid, lun;
    edt_entry_t *edt;
    int		error;

    /*
     * The EDT entry may already exist from a previous scan.
     */
    if ( edt = FindEdtByName(path) ) {
	bus = edt->edt_bus;
	tid = edt->edt_target;
	lun = edt->edt_lun;
    } else {
	error = GetScsiAddress(path, &bus, &tid, &lun, TRUE);
	if (error) return (error);
	edt = MakeEdtEntry (bus, tid, lun);
	if (edt == NULL) return (FAILURE);
	(void) SetupDevNames (edt, path);
    }
    scu->scu_bus = bus;
    scu->scu_target = tid;
    scu->scu_lun = lun;
    scu->scu_unit = 0;
    edt->edt_fd = scu->scu_fd;

    if ( !edt->edt_did_inquiry ) {
        (void) IssueInquiry (edt);
    }
    scu->scu_edt = edt;
    return (SUCCESS);
}

static edt_entry_t *
MakeEdtEntry(u_char pid, u_char tid, u_char lun)
{
    edt_t	*e;
    edt_entry_t	*edt;

    if (DebugFlag) {
	Printf("Making EDT entry for Bus %u, Target %u, LUN %u...\n",
						pid, tid, lun);
    }

    if ( (pid >= SCSI_BUSES) ||
	 (tid >= MAX_TARGETS) ||
	 (lun >= MAX_LUNS) ) {
	return (NULL);
    }

    if ((e = cam_edt[pid]) == NULL) {
	e = MakeAdapterEdtEntry(pid);
	if (e == NULL) return (NULL);
    }

    if (e->edt[tid] == (edt_entry_t **) 0) {
	e->edt[tid] = (edt_entry_t **)Malloc(TARGET_LUN_PTRS);
	if (!e->edt[tid]) return (NULL);
    }
    if (tid > e->edt_max_tid_seen) e->edt_max_tid_seen = tid;

    if ((edt = e->edt[tid][lun]) != NULL) {
	return (edt);	/* Already seen this device before. */
    } else {
	e->edt[tid][lun] = edt = (edt_entry_t *)Malloc(sizeof(*edt));
	if (!edt) return (NULL);
	/*
	 * Initialize initial data:
	 */
	edt->edt_bus			= pid;
	edt->edt_target			= tid;
	edt->edt_lun			= lun;
	edt->edt_target_lun_found	= TRUE;
	edt->edt_file_flags		= (FREAD | FWRITE);
	edt->edt_fd			= NULL_FD;
    }
    if (lun > e->edt_max_lun_seen) e->edt_max_lun_seen = lun;

    return (edt);
}

static edt_t *
MakeAdapterEdtEntry (u_char pid)
{
    edt_t *e;

    if (DebugFlag) {
	Printf("Making Adapter EDT entry for Bus %u...\n", pid);
    }

    if (pid >= SCSI_BUSES) return (NULL);

    if ((int)pid > max_bus_seen) max_bus_seen = (int)pid;
    if ((e = cam_edt[pid]) == NULL) {
	e = cam_edt[pid] = (edt_t *) Malloc(sizeof(*e));
	if (!e) return (NULL);
	e->edt = (edt_entry_t ***)Malloc(BUS_TARGET_PTRS);
	if (!e->edt) return (NULL);
	e->edt_bus_num = (u_char)pid;
	e->edt_dev_name = Malloc(sizeof(edt_dev_name_t));
	if (e->edt_dev_name == NULL) return (NULL);
    }
    return (e);
}

#if defined(GetAdapterInformation)
/*
 * TODO: Haven't found a way to do this on Solaris (yet).
 */
#define HOST_NAME_LEN	255	/* big enough? */

static int
GetAdapterName(int fd, edt_entry_t *edt)
{
    edt_t *e;
    int present = FALSE;
    char adapter[HOST_NAME_LEN];

    e = cam_edt[edt->edt_bus];
    if (!e) { Fprintf("no adapter?"); return (present); }
    if ( e->AdapterName ) return (present);

    bzero(adapter, sizeof(adapter));
    adapter[0] = sizeof(adapter);
    /*
     * TODO: How to get adapter info on Solaris?
     */
#if 0
    present = ioctl(fd, SCSI_IOCTL_PROBE_HOST, adapter);
#endif
    if ( present && DebugFlag ) Printf("Adapter is '%s'\n", adapter);
    e->AdapterName = strdup(adapter);
    return (present);
}

#endif /* defined(GetAdapterInformation) */

static int
OpenDevice(char *device, int *fdp, boolean_t exclusive)
{
    int fd, error;
    int mode = (O_RDWR|O_NONBLOCK);

    if (exclusive) mode |= O_EXCL;
    if (DebugFlag) {
        Printf("Attempting to open '%s' read-write, mode = %#o...\n",
						device, mode);
    }

    /*
     * Close previously opened file descriptor.
     */
    if (*fdp != NULL_FD) {
        (void)close(*fdp);
	*fdp = NULL_FD;
    }

    /*
     * NOTE: The O_NONBLOCK tells us if the device is busy.
     */
    fd = open(device, mode);
    if (fd == FAILURE) {
	if (DebugFlag) {
	    Perror ("open R/W failed");
	    Printf ("Attempting to open '%s' read-only (mode %#o)...\n",
						device, mode);
	}
	mode = (O_RDONLY | O_NONBLOCK);
	if (exclusive) mode |= O_EXCL;
	fd = open(device, mode);
	if (fd == FAILURE) {
	    if (PerrorFlag || DebugFlag) {
		Perror("%sopen of '%s' failed",
		   (exclusive) ? "exclusive " : "", device);
	    }
	    return (FAILURE);
	}
    }

    /*
     * Now, disable non-blocking flag for our requests.
     */
    mode = fcntl(fd, F_GETFL);
    if (mode == FAILURE) {
        Perror("fcntl(F_GETFL) failed on '%s'", device);
    } else {
        error = fcntl(fd, F_SETFL, (mode & ~O_NONBLOCK));
	if (error == FAILURE) {
	    Perror("fcntl(F_SETFL) failed on '%s'", device);
	}
    }

    *fdp = fd;
    return (SUCCESS);
}

static edt_entry_t *
FindEdtByName(char *device_entry)
{
    edt_dev_name_t *edt_nm;
    /*
     * Search the global name list:
     */
    for (edt_nm = edt_dev_names; edt_nm; edt_nm = edt_nm->forw) {
	if (strcmp (edt_nm->name, device_entry) == 0) {
	    return (edt_nm->edt);
	}
    }
    return ((edt_entry_t *) 0);
}

static int
SetupDevNames(edt_entry_t *edt, char *device_entry)
{
    edt_dev_name_t	*dev_name;

    /*
     * Setup pointer to the first device path.
     */
    if (edt->edt_path == NULL) {
	edt->edt_path = strdup(device_entry);
    }
    if ( FindEdtByName(device_entry) ) {
	return (SUCCESS); /* Name already on list. */
    }
    dev_name = Malloc(sizeof(edt_dev_name_t));
    if (!dev_name) return (FAILURE);

    dev_name->edt	= edt;
    dev_name->name	= strdup(device_entry);

    /*
     * Link on global name list.
     */
    dev_name->forw	= edt_dev_names;
    if (edt_dev_names) {
	edt_dev_names->back = dev_name;
    }
    dev_name->back	= (edt_dev_name_t *)NULL;
    edt_dev_names	= dev_name;
    edt->edt_dev_name	= dev_name;

    return (SUCCESS);
}

static void
DumpUscsiCmd(int fd, struct uscsi_cmd *scp)
{
    int i;
    cdp ("\nDumping SCSI Cmd Structure: %#lx\n\n", scp);

    cdp ("    File Descriptor .............................. fd: %d\n", fd);
    cdp ("    Control Flags ....................... uscsi_flags: %#x\n", scp->uscsi_flags);
    cdp ("    SCSI Result Status ................. uscsi_status: %#x (%s)\n",
		scp->uscsi_status, cdbg_ScsiStatus(scp->uscsi_status, CDBG_BRIEF));
    cdp ("    Command Timeout ................... uscsi_timeout: %d seconds\n", scp->uscsi_timeout);
    cdp ("    Command Descriptor Block .............. uscsi_cdb: %#lx ->", scp->uscsi_cdb);
    for (i = 0; (i < scp->uscsi_cdblen); i++) {
	cdp (" %x", ((uchar_t *)scp->uscsi_cdb)[i]);
    }
    cdp ("\n");
    cdp ("    CDB Length ......................... uscsi_cdblen: %d\n", scp->uscsi_cdblen);
    cdp ("    I/O Buffer Address ................ uscsi_bufaddr: %#lx\n", scp->uscsi_bufaddr);
    cdp ("    I/O Buffer Length .................. uscsi_buflen: %d (%#x)\n",
							scp->uscsi_buflen, scp->uscsi_buflen);
    cdp ("    I/O Residual Count .................. uscsi_resid: %d (%#x)\n",
							scp->uscsi_resid, scp->uscsi_resid);
    cdp ("    Request Sense Buffer ................ uscsi_rqbuf: %#lx\n", scp->uscsi_rqbuf);
    cdp ("    Request Sense Length ................ uscsi_rqlen: %d (%#x)\n",
							scp->uscsi_rqlen, scp->uscsi_rqlen);
    cdp ("    Request Sense Status ............. uscsi_rqstatus: %#x (%s)\n",
		scp->uscsi_rqstatus, cdbg_ScsiStatus(scp->uscsi_rqstatus, CDBG_BRIEF));
    cdp ("\n");
}

static char *dev_directories[] = {
	"/dev", "/dev/rdsk", "/dev/rmt", NULL
};

static int
DoDeviceScan(void)
{
    static		int devices_found = 0;
    int			d, i, scan_fd;
    struct dirent	*dp;
    DIR			*dirp;
    char		*devp;
    char		path[PATH_MAX+1];

    if (devices_scanned) return (devices_found);
    bzero(path, sizeof(path)); /* For debug only. */
    for (d = 0; dev_directories[d]; d++) {
	devp = dev_directories[d];
	(void)strcpy(path, devp);
	if (!(dirp = opendir(path))) {
	    if (DebugFlag) {
		Perror ("Error opening '%s'", path);
	    }
	    continue; /* Try the next directory. */
	}
	i = strlen(path);
	path[i++] = '/';
	while (dp = readdir(dirp)) {
	    if (CmdInterruptedFlag) break;
	    strcpy (&path[i], dp->d_name);
	    if ( !isValidDeviceName(path) ) continue;
	    if (DebugFlag) {
		Fprintf("Processing device '%s'...\n", path);
	    }
	    if ((scan_fd = open (path, (O_RDONLY|O_NONBLOCK))) == FAILURE) { 
		if (DebugFlag || CamDebugFlag) {
		    Perror ("Unable to open device '%s'", path);
		}
		continue;
	    }
	    /*
	     * See if this is a SCSI device by requesting information.
	     */
	    if (SetupDeviceEntry (path, scan_fd) == FAILURE) {
		close (scan_fd);
		continue;
	    }
	    devices_found++;
	    close (scan_fd);
	}
	closedir (dirp);
    }
    if (devices_found) devices_scanned = TRUE;
    return (devices_found);
}

/*
 * isValidDeviceName() - Check for Valid Devices.
 *
 * Inputs:
 *	device_entry = The device entry (path);
 *	Assumption is this is full path w/dev prefix.
 *
 * Return Value:
 *	True = Valid Device, False = Invalid Device.
 *
 * Please Note: GetScsiAddress() also parses device names
 *		since this is how bus/tid/lun is obtained.
 */
static boolean_t
isValidDeviceName(char *device_entry)
{
    char *device = (strrchr(device_entry, '/') + 1);
    size_t end = (strlen(device) - 1);
    /*
     * Due to the side effects of opening all device names (SCSI or not),
     * to see if they respond to SCSI commands, the device name is now
     * qualified.  Otherwise too many non-SCSI devices hose the system.
     */
    if ( EQL(device, "rsd", 3) ) {
	if (device[end] == 'c') {
	    ;
	} else {
	    return (FALSE);
	}
    } else if ( EQL(device, "rsr", 3) ) {
	;
    } else if ( EQS(device_entry, "rmt/") ) {
	/* Only accept compressed no-rewind tape device names. */
	if (isdigit((int)device[0]) && (device[end-1] == 'c') && (device[end] == 'n')) {
	    ;
	} else {
	    return (FALSE);
	}
    } else if ( EQS(device_entry, "rdsk/") ) {
	/* Only accept controller slice 0 disk names. */
	if ((device[0] == 'c') && (device[end-1] == 's') && (device[end] == '0')) {
	    ;
    	} else {
	    return (FALSE);
	}
    } else {
	return (FALSE);
    }
    return (TRUE);
}

/*
 * SetupDeviceEntry() - Setup Device Entry.
 *
 * Description:
 *	This function is called while scanning the device directories
 * looking for SCSI devices to populate our internal EDT.
 *
 * Inputs:
 *	path = The device path name (i.e., /dev/rdsk/...)
 *	fd = The file descriptor (device is open on).
 *
 * Return Value:
 *	Returns Succss/Failure = Device Setup/Not Valid SCSI device.
 *
 */
static int
SetupDeviceEntry(char *path, int fd)
{
    u_char bus, tid, lun;
    edt_entry_t temp_edt;
    edt_entry_t *edt, *tedt = &temp_edt;
    int error;

    error = GetScsiAddress(path, &bus, &tid, &lun, FALSE);
    if (error) return (error);

    bzero(tedt, sizeof(*tedt));
    tedt->edt_bus = bus;
    tedt->edt_target = tid;
    tedt->edt_lun = lun;
    tedt->edt_fd = fd;

    /*
     * We assume a valid SCSI device if Inquiry succeeds.
     */
    error = IssueInquiry(tedt);
    if (error) return (error);

    if ( !(edt = MakeEdtEntry(bus, tid, lun)) ) {
	return (FAILURE);
    }

    /*
     * This is messy, but necessary.
     */
    edt->edt_did_inquiry = tedt->edt_did_inquiry;
    bcopy(&tedt->edt_inquiry, &edt->edt_inquiry, sizeof(inquiry_t));

    error = SetupDevNames(edt, path);

    return (error);
}

static int
GetScsiAddress(
	char		*path,
	u_char		*bus,
	u_char		*tid,
	u_char		*lun,
	boolean_t	warn_flag)
{
    char *sptr, *eptr;
    char linkpath[PATH_MAX+1];
    char *invalid_str = "Invalid SCSI device name '%s'!\n";
    int error = SUCCESS;

    /*
     * TODO: Haven't found a way to obtain tape nexus info.
     */
    if ( EQS(path, "rmt/") ) {
	error = GetTapeAddress(path, bus, tid, lun, warn_flag);
	if (error) {
	    return (error);
	}
	goto announce;
    }

    /*
     * I can't find an IOCTL to obtain the SCSI address, so I'm
     * parsing the device name, which is expected to be the form:
     *
     *   /dev/subdir/cNtNdNsN
     *
     * Where:
     *    c = controller (bus)
     *    t = target
     *    d = drive (lun)
     *    s = slice
     *
     * TODO: There *must* be a better way to accomplisg this.
     *
     * The alternative is to parse the symbolic link data:
     *
     * ../../devices/pci@0,0/pci8086,2418@1e/pcie11,b1bd@7/sd@1,0:a,raw
     */
    if ( (sptr = strrchr(path, '/')) == NULL) {
	sptr = path;
    } else {
	sptr++;
    }
    /*
     * Check for devices which are links to cNtNdNsN file.
     */
    linkpath[0] = '\0';
    if ( EQL(sptr, "rsd", 2) ||
	 EQL(sptr, "rsr", 2) ) {
	int count;
	if ( (count = readlink (path, linkpath, sizeof(linkpath))) < 0) {
	    if (DebugFlag && warn_flag) {
		Perror("readlink() of '%s' failed", path);
	    }
	    return (FAILURE);
	}
	if ( (sptr = strrchr(linkpath, '/')) == NULL) {
	    sptr = linkpath;
	} else {
	    sptr++;
	}
    }
    if (*sptr++ != 'c') {
	if (warn_flag) {
	    Fprintf(invalid_str, path);
	}
	return (FAILURE);
    }
    *bus = strtol(sptr, &eptr, 10);
    if ( (sptr == eptr) || (*eptr++ != 't') ) {
	if (warn_flag) {
	    Fprintf(invalid_str, path);
	}
	return (FAILURE);
    } else if (*bus > SCSI_BUSES) {
	Fprintf("Bus %u is too big!\n", *bus);
	return (FAILURE);
    }
    sptr = eptr;
    *tid = strtol(sptr, &eptr, 10);
    if ( (sptr == eptr) || (*eptr++ != 'd') ) {
	if (warn_flag) {
	    Fprintf(invalid_str, path);
	}
	return (FAILURE);
    } else if (*tid > MAX_TARGETS) {
	Fprintf("Target %u is too big!\n", *tid);
	return (FAILURE);
    }
    sptr = eptr;
    *lun = strtol(sptr, &eptr, 10);
    if ( (sptr == eptr) || (*eptr++ != 's') ) {
	if (warn_flag) {
	    Fprintf(invalid_str, path);
	}
	return (FAILURE);
    } else if (*lun > MAX_LUNS) {
	Fprintf("LUN %u is too big!\n", *lun);
	return (FAILURE);
    }
announce:
    if (DebugFlag) {
	Printf ("Device '%s', Bus %u, Target %u, LUN %u\n",
					path, *bus, *tid, *lun);
    }
    return (SUCCESS);
}

static int
GetTapeAddress(
	char		*path,
	u_char		*bus,
	u_char		*tid,
	u_char		*lun,
	boolean_t	warn_flag)
{
    char *sptr, *eptr;
    char linkpath[PATH_MAX+1];
    char *invalid_str = "Invalid tape device name '%s'!\n";
    int count;
    static u_char myTapeBus = SCSI_BUSES;

    if ( (count = readlink (path, linkpath, sizeof(linkpath))) < 0) {
	if (DebugFlag && warn_flag) {
	    Perror("readlink() of '%s' failed", path);
	}
	return (FAILURE);
    }

    /*
     * Parse tape address from:
     * ../../devices/pci@0,0/pci8086,2418@1e/pci9004,7850@b/st@6,0:cn
     */
    if ( (sptr = strstr(linkpath, "/st@")) == NULL) {
	if (warn_flag) {
	    Fprintf(invalid_str, path);
	    return (FAILURE);
	}
    }
    sptr = (sptr + 4);
/* Cludge Alert */
    *bus = --myTapeBus; /* --> for now, until we find bus # <-- */
/* End of Cludge */
    *tid = strtol(sptr, &eptr, 10);
    if ( (sptr == eptr) || (*eptr++ != ',') ) {
        if (warn_flag) {
            Fprintf(invalid_str, path);
        }
        return (FAILURE);
    } else if (*tid > MAX_TARGETS) {
        Fprintf("Target %u is too big!\n", *tid);
        return (FAILURE);
    }
    sptr = eptr;
    *lun = strtol(sptr, &eptr, 10);
    if ( (sptr == eptr) || (*eptr++ != ':') ) {
        if (warn_flag) {
            Fprintf(invalid_str, path);
        }
        return (FAILURE);
    } else if (*lun > MAX_LUNS) {
        Fprintf("LUN %u is too big!\n", *lun);
        return (FAILURE);
    }
    return (SUCCESS);
}
